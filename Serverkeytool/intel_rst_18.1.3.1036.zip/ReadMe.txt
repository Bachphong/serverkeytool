**************************************************************************
**************************************************************************
*                           Installation Readme for 
*    Intel(R) Rapid Storage Technology (Intel(R) RST) with Support for:
*     - Intel(R) Optane(TM) Memory System Acceleration^^
*     - RAID 0/1/5/10^^
*     - CPU Attached Storage^^
*      ^^ NOTE: Support for this feature is determined by your hardware configuration
*
* This document makes references to products developed by Intel. There are some 
* restrictions on how these products may be used, and what information may be disclosed to 
* others. Please read the Disclaimer section at the end of this document, and contact 
* your Intel field representative if you would like more information.
*
**************************************************************************
**************************************************************************

**************************************************************************
* Intel is making no claims of usability, efficacy or warranty. The INTEL SOFTWARE LICENSE 
* AGREEMENT contained herein completely defines the license and use of this software.
**************************************************************************

**************************************************************************
*                 CONTENTS OF THIS DOCUMENT                              *
**************************************************************************

This document contains the following sections:

1.  Supported Platforms/Chipsets
2.  System Requirements
3.  Language Support
4.  INTEL(R) OPTANE(TM) TECHNOLOGY BASED SYSTEM ACCELERATION 
5.  Determining the System Mode 
6.  Installing the Software
7.  Verifying Installation of the Software
8.  Advanced Installation Instructions
9.  Identifying the Software Version Number
10. Uninstalling the Software
11. Entering the pre-OS User Interface
12. Pre-OS RAID Volume Management
13. Options to RESET the RAID volume in the Pre-OS UI's
14. Verifying the Version of the Pre-OS UEFI Driver/OptionROM SOFTWARE

**************************************************************************
* 1.  SUPPORTED PLATFORMS/CHIPSETS
**************************************************************************
This Intel(R) Rapid Storage Technology Release is designed to provide functionality
for the following Storage Controllers (Tiger Lake Platforms, Rocket Lake, Comet Lake Platforms):

1.a VMD Platforms - Tiger Lake Platform Series: 
 Mobile Low Power (LP)
 - Premium UP3
 - Premium UP4
 - Premium H35

1.b Non-VMD/Legacy platforms - Rocket Lake, Comet Lake, Ice Lake Platform Series:
 - Intel(R) 500 Series Chipset Family:
  Desktop, High End Desktop (HEDT), Workstation (WS)
  - Z590
  - Q570	- W580(WS)
  - H570
  - B560
  - H510
 
 - Intel(R) 400 Series Chipset Family:
  Desktop, High End Desktop (HEDT), Workstation (WS)
  - Z490
  - Q470	- W480(WS)
  - H470
  - B460
  - H410
  Mobile Halo
  - HM470
  - QM480
  - WM490
  Intel(R) 10th Generation Core Processor Family Platform I/O SATA AHCI/RAID Controller
  Mobile Low Power (LP)
  - Premium-U

**************************************************************************
* 2.  SYSTEM REQUIREMENTS
**************************************************************************

A.  The system must contain one of the Intel controllers listed in Section 1 �SUPPORTED 
    PLATFORMS/CHIPSETS� above and one of the following types of processors***:
    - Intel(R) vPro(TM)
    - Intel(R) Celeron(R)
    - Intel(R) Pentium(R)
    - Intel(R) Core� i3, i5, i7 or i9
    - Intel(R) Xeon(R) processor family

***Note: There are certain Intel(R) Rapid Storage Technology features that are only 
   enabled based upon the system's processor
    
B.  The system must be running one of the following operating systems (no other Windows
    OS versions are supported):
    - Microsoft Windows* 10 x64 Edition** (current RTM version)

C.  The following operating systems are not supported in any versions or updates:
    - Linux*
    - UNIX*
    - BeOS*
    - MacOS*
    - OS/2*

D.  The system should contain at least the minimum system memory required by the operating
    system. Consult your computer system and OS vendor.
    *Other names and brands may be claimed as the property of others.

**************************************************************************
* 3.  LANGUAGE SUPPORT
**************************************************************************

Below is a list of the languages (and their abbreviations) for which the Intel(R) Rapid 
Storage Technology software has been localized. The language code is listed in parentheses 
after each language.

ARA: Arabic (Saudi Arabia)       (0401)
CHS: Chinese (Simplified)        (0804)
CHT: Chinese (Traditional)       (0404)
CSY: Czech                       (0405)
DAN: Danish                      (0406)
NLD: Dutch                       (0413)
ENU: English (United States)     (0409)
FIN: Finnish                     (040B)
FRA: French (International)      (040C)
DEU: German                      (0407)
ELL: Greek                       (0408)
HEB: Hebrew                      (040D)
HUN: Hungarian                   (040E)
ITA: Italian                     (0410)
JPN: Japanese                    (0411)
KOR: Korean                      (0412)
NOR: Norwegian                   (0414)
PLK: Polish                      (0415)
PTB: Portuguese (Brazil)         (0416)
PTG: Portuguese (Standard)       (0816)
RUS: Russian                     (0419)
Rum/Ron: Romanian          (639-2/T) / (639-2/B)
ESP: Spanish                     (0C0A)
SVE: Swedish                     (041D)
SLO: Slovak 					(0693)
THA: Thai                        (041E)
TRK: Turkish                     (041F)

**************************************************************************
* 4  INTEL(R) OPTANE(TM) TECHNOLOGY BASED SYSTEM ACCELERATION
**************************************************************************

4.A  INTEL(R) OPTANE(TM) MEMORY SUPPORTED PLATFORMS/CHIPSETS
--------------------------------------------
Intel(R) Optane(TM) Technology based System Acceleration is designed to provide 
functionality for the following Storage Controllers of the Intel PCH:

4.A.1 VMD Platforms - Tiger Lake Platform Series: 
 Mobile Low Power (LP)
 - Premium UP3
 - Premium UP4
 - Premium H35

4.A.2 Non-VMD/Legacy platforms - Rocket Lake, Comet Lake, Ice Lake Platform Series:
 - Intel(R) 500 Series Chipset Family:
  Desktop, High End Desktop (HEDT), Workstation (WS)
  - Z590
  - Q570	- W580(WS)
  - H570
  - B560
  - H510

  Intel(R) 400 Series Chipset Family:
  Desktop, High End Desktop (HEDT), Workstation (WS)
  - Z490
  - Q470	- W480(WS)
  - B460
  - H470
  - H410
  Mobile Halo
  - HM470
  - QM480
  - WM490
  Intel(R) 10th Generation Core Processor Family Platform I/O SATA AHCI/RAID Controller
  Mobile Low Power (LP)
  - Premium-U
   
4.B  SYSTEM REQUIREMENTS for INTEL(R) OPTANE(TM) MEMORY SYSTEM ACCELERATION 
--------------------------------------------------------------
4.B.1 VMD platforms - Tiger Lake Platform Series: 

i.  The system must contain one of the Intel controllers listed in Section 1 �SUPPORTED 
    PLATFORMS/CHIPSETS� above and one of the following types of processors***:
    - Intel(R) vPro
    - 11th Gen Intel(R) Core(TM) i3, i5, i7 or i9 processors
    - Intel(R) Xeon(R) E3 v6 processor family    
ii.  The system must be running one of the following operating systems (no other Windows
     OS versions are supported):
        - Microsoft Windows* 10 x64 Edition (current RTM)
iii.  The system should contain at least the minimum system memory required by the
      operating system. Consult your computer system and OS vendor.
        *Other names and brands may be claimed as the property of others
iv.   The system must contain one of the following supported Intel(R) Optane(TM)
      technologies populated into the storage connector labeled �Intel(R) Optane(TM)
      Memory Ready� or �Intel(R) Optane(TM) Ready�:
	   -Intel(R) Optane(TM) memory modules
v.    The system must contain one of the following supported backend (slow media system
      disk) storage devices: 
         -SATA HDD
         -SATA SSD
         -SATA SSHD**
          **Self-pinning SSHDs only, SSHDs that use the Hybrid Information Feature Set are
            not supported
vi.   VMD device should ALWAYS be ENABLED in the BIOS. 
vii.  System integrators can choose the storage devices on the platform to be
	  under VMD controlled in order to create the desired storage configuration.
	  VMD-controlled storage devices will be accessed through the Intel(R) RST VMD driver.
	  Intel� RST driver for VMD only supports SATA Controller when SATA Controller is
	  mapped under VMD.
viii. For the storage devices that system integrators do not configure to be under
	  VMD control, Windows* Inbox driver will be used to access the device.

	  
4.B.2 Non-VMD/Legacy platforms - Rocket Lake, Comet Lake Platform Series:

i.  The system must contain one of the Intel controllers listed in Section 1 �SUPPORTED 
    PLATFORMS/CHIPSETS� above and one of the following types of processors***:
    - Intel(R) vPro
    - 10th Gen Intel(R) Core(TM) i3, i5, i7 or i9 processors
    - Intel(R) Xeon(R) E3 v6 processor family        
ii.  The system must be running one of the following operating systems (no other Windows
     OS versions are supported):
        - Microsoft Windows* 10 x64 Edition (current RTM)
iii.  The system should contain at least the minimum system memory required by the
      operating system. Consult your computer system and OS vendor.
        *Other names and brands may be claimed as the property of others
iv.   The system must contain one of the following supported Intel(R) Optane(TM)
      technologies populated into the storage connector labeled �Intel(R) Optane(TM)
      Memory Ready� or �Intel(R) Optane(TM) Ready�:
	   -Intel(R) Optane(TM) memory modules
v.    The system must contain one of the following supported backend (slow media system
      disk) storage devices: 
         -SATA HDD
         -SATA SSD
         -SATA SSHD**
          **Self-pinning SSHDs only, SSHDs that use the Hybrid Information Feature Set are
            not supported
vi.    The system PCH SATA controller mode must be set to one of the following modes: 
	-�Intel� RST and System Acceleration with Intel� Optane� Technology�
	-�Intel� RST Premium and System Acceleration with Intel� Optane� Technology�

4.C  CONFIGURING INTEL(R) OPTANE(TM) TECHNOLOGY BASED SYSTEM ACCELERATION
-------------------------------------------------------------------------

I: INTEL(R) RST UI/Installer

This method is targeted for experienced users who want to have control of the
configuration process are recommended to use this method.

1. Obtain the Intel(R) RST SW/driver installation package and run the executable (SetupRST.exe)
2. Install the defaults and reboot the computer
3. From Windows desktop, find and launch the Intel� Optane(TM) Memory and Storage Management application.
4. The application will open to the �Manage� page
5. Click the �Intel(R) Optane(TM) Memory� tab
6. Select disk configuration
7. Click the �Enable Intel(R) Optane(TM) Memory".
8. Choose mode for Intel(R) Optane(TM) Memory and click Next
9. Check "Erase all data on Intel(R) Optane(TM) memory module"
10. Click the �Enable� link to start the enabling process
11. Depending on the size of your Intel(R) Optane(TM) memory module, a progress bar may be displayed
12. Let progress bar complete to 100%
13. Finalize operation
14. Click the [Reboot] button to complete the process
15. System reboots into Windows to complete the enabling process.
    
* 4.D  DISABLING INTEL(R) OPTANE(TM) TECHNOLOGY BASED SYSTEM ACCELERATION
-------------------------------------------------------------------------
Pre-OS
1. Restart the computer and enter the BIOS
2. Enter the Intel(R) RST HII UI
3. Select the Intel(R) Optane(TM) Memory volume, then select �Deconcatenate� and complete the following:
     a. [X] Checkbox to preserve user data upon deconcatenation; Checked is the default
     b. <No> Decision box to confirm deconcatenation action; Yes or No (No is default)

Intel(R) Optane(TM) Memory and Storage Management UI 
1. From Windows desktop, find and launch the Intel� Optane(TM) Memory and Storage Management application.
2. The application will open to the �Manage� page
3. Click the �Intel(R) Optane(TM) Memory� tab
4. Click the �Disable� link to start the disabling process
5. Click Disable and wait for the progress to complete 
6. Click the [Reboot] button to complete the process


**************************************************************************
* 5.  DETERMINING THE SYSTEM MODE - ONLY FOR NON-VMD/Legacy PLATFORM SERIES
**************************************************************************

***Note: This Readme document assumes that your system is running a supported Intel-based 
CPU and Chipset that supports only RAID and/or AHCI modes for the PCH SATA AHCI 
Controller (RAID is replaced by �Intel(R) RST Premium�� also an additional mode supporting Intel(R) Optane(TM) Memory only called �Intel(R) RST��). If not, then this driver is not supported on your system HW. Please exit this setup.

To use this Readme effectively, you will need to know what mode the PCH SATA AHCI 
controller in your system is in. The easiest way to determine the mode is to identify how 
the Intel(R) SATA controller is presented within �Device Manager�. The following 
procedures will guide you through determining the mode in Microsoft Windows 10* or higher 
OS versions:

A.  In Windows 10 Desktop, right click the �Start� button located at the bottom left 
    corner of the Desktop.

B.  The �Start� menu will launch.

C.  Scroll up and select 'Device Manager' with left mouse click.

D.  In the Device Manager window, look for an entry named Storage Controllers. Left click
    and expand the item. If there is an entry for an �Intel(R) brand SATA RAID� controller
    (or similar entry with the �Intel� name somewhere in the entry), then the system is in 
    RAID mode (Intel(R) RST Premium with Intel(R) Optane(TM) Technology mode).
    
E.  If no �Intel SATA RAID Controller� controller is listed in the step above, then the 
    system is not running in RAID or �Intel(R) RST..� or �Intel(R) RST Premium� mode and is in 
    AHCI mode (see next step 6).

F.  From the Device Manager, look for an entry named 'IDE ATA/ATAPI controllers'. In AHCI
    mode this entry is present, expand it and look for a �SATA AHCI� controller which 
    identifies the system is in AHCI mode.


**************************************************************************
* 6.  INSTALLING THE SOFTWARE
**************************************************************************

6.1 General Installation Notes

a.  If you are installing the operating system on a computer configured for RAID or AHCI
    mode, you may pre-install the Intel(R) Rapid Storage Technology driver using the 
    "F6" (Load Driver) installation method described in section 6.3 below.

b.  If you�re installing the operating system on a computer configured for �Intel(R) Smart 
    Response Technology� or �System Acceleration with Intel(R) Optane(TM) Technology�, you 
    must pre-install the Intel(R) Rapid Storage Technology driver using the 
    "F6" (Load Driver) installation method described in section 6.3 below.  The Intel(R) RST pre-OS version must support the Intel(R) RST technology that you are installing to.

c.  To install Intel(R) Rapid Storage Technology from within the OS during runtime, 
    double-click on the self-extracting and self-installing setup file and answer all
    prompts presented.

6.2 Intel(R) RST Windows Automated Installer*. Installation from HDD, USB, or CD-ROM
Note: This method is applicable to computers configured for RAID or AHCI mode.

a.  Obtain the Intel(R) Rapid Storage Technology setup file name: SetupRST.exe) and
    double-click to self-extract and to begin the setup process.

b.  The Welcome window appears. Click 'Next' to continue.

c.  For systems running in RAID mode, the Uninstallation Warning window appears. You will 
    not be able to uninstall the driver in this mode. Click 'Next' to continue.

d.  The Software License Agreement window appears. If you agree to these terms, click the
    check box then click 'Yes' to continue.

e.  Select the check box to install Intel(R) Optane(TM) Memory and Storage Management application if required then click 'Next' to continue.

f.  If the Windows Automated Installer* Wizard Complete window is shown without a prompt 
    to restart the system, click 'Finish' and proceed to step �g�. If it is shown with a 
    prompt to restart the system, select �I want to restart my computer now.' 
    (selected by default) and click 'Finish'. Once the system has restarted, proceed to 
    step �g�.

g.  To verify that the driver was loaded correctly, refer to section 7.

6.3 Pre-Installation of INTEL(R) RST driver using the "Load Driver" Method.

a.  Copy all driver files from the f6vmdflpy-x64 to a USB key media.

b.  For Microsoft Windows OS*:
    - During the operating system installation, after selecting the location to install 
      Windows, click 'Load Driver' to install a third party SCSI or RAID driver.

c.  When prompted, insert the USB media and press Enter.

d.  Follow the prompts and browse to the location of the installation files.  Select the 
    appropriate �.inf� file (64 or 32 bit).  If a supported controller is detected there 
    will be no error message. Follow prompts to continue and complete the installation.


**************************************************************************
* 7.  VERIFYING INSTALLATION OF THE SOFTWARE
**************************************************************************

Verifying �Have Disk�, 'Load Driver', or �Unattended Installation�: 
Depending on your system configuration, refer to the appropriate sub-topic below:

7.1 VMD Platform series:

A.  Enter Device Manager once you are logged into Windows OS.    
B.  Expand the 'Storage Controllers' entry for Windows 10*.
C.  Right-click on Intel(R) RST VMD Controller.    
D.  Select 'Properties'.
E.  Select the 'Driver' tab and you should see the following items.
	- [Driver Provider] should be �Intel�
	- [Driver Version] should be the INTEL(R) RST driver version just installed
    If these 2 items are correct, then the installation was successful.

7.2 Non-VMD/Legacy Platform Series: 

A.  Enter Device Manager once you are logged into Windows OS.    
B.  Expand the 'Storage Controllers' entry for Windows 10*.
C.  Right-click on Intel(R) SATA RAID Controller.    
D.  Select 'Properties'.
E.  Select the 'Driver' tab and you should see the following items.
	- [Driver Provider] should be �Intel�
	- [Driver Version] should be the INTEL(R) RST driver version just installed
    If these 2 items are correct, then the installation was successful.

**************************************************************************
* 8.  ADVANCED INSTALLATION INSTRUCTIONS
**************************************************************************
********************
8.1a INTEL(R) RST INSTALLER (SetupRST.exe)- Setup Flags for INTEL(R) RST Installer:
********************
NOTE: Setup flags are NOT case sensitive (i.e. �a� or �A� is the same flag value)
	[ -help | -? ]
	Display this help.

	[-report] <directory>	
	Path to directory where logs files will be saved.
	
	[-reportfile] <filename>	
	Path and log filename where installer information will be written to.

	[ -silent | -s ]
	Does not display any setup dialogs (silent install).

	[ -nodriver | -nodrv ]
	Installs only Intel Optane� Optane� Memory and Storage Management.

	[ -onlydriver ]
	Install only Intel� RST driver
	
	[-raidswitch]
	Enforces switch of the SATA controller from AHCI to Intel� RST Premium mode when installing in silent mode. This flag does not apply to Intel� VMD (Volume Management Device) platforms.

	[ -accepteula ]
	This option is mandatory while silent install and means that you accept the End User License Agreement (EULA)
	Please read the EULA in the GUI installer before accepting it on the command line.

Notes:  Flags and their parameters are not case-sensitive. Flags may be supplied in any 
        order, with the exception of the -S and -G, which must be supplied last. When 
        using the -A flag, a target path may be specified via the -P flag, -G, -S, and -N 
        flags are ignored. When using the -P flags, there should be space between the flag 
        and the argument.

**************************************************************************
* 9.  IDENTIFYING THE SOFTWARE VERSION NUMBER
**************************************************************************
9.1 Use the following steps to identify the software version number following a �Have 
Disk�, 'Load Driver', or �unattended installation�.

9.1.a VMD Platform Series: 

A.  Enter the 'Device Manager'.
B.  Expand the 'Storage Controllers' entry.
C.  Right-click on the Intel(R) RST VMD Controller present.
D.  Select 'Properties'.
E.  Select the 'Driver' tab.
F.  The software version should be displayed after 'Driver Version:'
	
9.1.b Non-VMD/Legacy Platform Series: 

1. Systems Configured for either RAID, INTEL(R) RST, or �INTEL(R) RST Premium� Mode:
A.  Enter the 'Device Manager'.
B.  Expand the 'Storage Controllers' entry.
C.  Right-click on the Intel(R) RAID Controller present.
D.  Select 'Properties'.
E.  Select the 'Driver' tab.
F.  The software version should be displayed after 'Driver Version:'

2. Systems Configured for AHCI Mode:
A.  Enter the 'Device Manager'.
B.  Expand the 'IDE ATA/ATAPI controllers' entry.
C.  Right-click on the Intel(R) AHCI Controller present.
D.  Select 'Properties'.
E.  Select the 'Driver' tab.
F.  The software version should be displayed after 'Driver Version:'

9.2 Identify the software version for Windows* Automated Installer or 'Package for the 
    Web' Installations:
1.  Click Start.
2.  Locate and select 'Intel� Optane(TM) Memory and Storage Management'. 
3.  The Intel� Optane(TM) Memory and Storage Management application should launch.
4.  From the Help window, click 'About'. The software version is displayed. 
    
**************************************************************************
* 10.  UNINSTALLING THE SOFTWARE
**************************************************************************

10a. UNINSTALLATION OF NON-DRIVER COMPONENTS
The removal of this software from the system will render any SATA disks inaccessible by 
the operating system; therefore, the uninstallation procedure will only uninstall non-
critical components of this software (user interface, start menu links, etc.). To remove 
critical components, see section 10b. 

Use the following procedure to uninstall the software:
1.  On the Start menu, select Intel� Optane(TM) Memory and Storage Management App.
2.  Right-click the application name, and then click 'Uninstall'.
3.  The uninstall program will start. Click through the options for the uninstallation.


10b. UNINSTALLATION OF DRIVER COMPONENTS
!!!!!!!!!!! WARNING !!!!!!!!!! WARNING !!!!!!! WARNING !!!!!!!!! WARNING !!!!!!!!!
The removal of this software from the system could render any SATA or NVMe disks/volumes 
inaccessible by the operating system. Back-up any important data before completing these 
steps.

Note: If you experience any difficulties making these changes to the system BIOS, please 
contact the motherboard manufacturer or your place of purchase for assistance.
 
**************************************************************************
* 11.  ENTERING THE Pre-OS USER INTERFACE
**************************************************************************

UEFI Driver/BIOS
*****************************
  Use the following steps to enter the Intel(R) Rapid Storage Technology UEFI HII-
  compliant user interface (Note: the exact steps and location of the UI is OEM platform 
  dependent.  You must consult your platform manufacturer for these exact steps and 
  location of the Intel(R) RST UEFI HII UI):

    1. Boot the system.
    2. Press key required to enter the platform's system BIOS (e.g F2)
    3. Locate the �Intel(R) Rapid Storage Technology� item wherever it is located in your 
       platform�s system BIOS menu and enter it to launch the �Intel(R) Rapid Storage 
       Technology� text-based UEFI UI. At the top of the main page of the UI the version 
       is indicated in the following format:
        'Intel(R) RST ww.x.y.zzzz SATA Driver�


**************************************************************************
* 12.  Pre-OS STORAGE SUB-SYSTEM MANAGEMENT
**************************************************************************

UEFI Driver/BIOS HII
*****************************
The Intel(R) Rapid Storage Technology - UEFI UI provides pre-OS Storage sub-system 
management which enables the following capabilities:

I- RAID Volume Management
1. Create RAID Volume
   Use this option to create one or two RAID volumes.

2. Delete
   Click on a RAID volume then use this option to delete the RAID volume. The pre-OS 
   methods are the only end-user methods to delete a RAID volume that has the OS boot 
   files on it.

3. Reset to Non-RAID 
   Click on a RAID volume then click on a member disk then use this option to reset a RAID 
   member disk to a non-RAID pass-through disk.

4. Recovery Volume Options
   If a recovery volume is present, use this option to 
        a. Disable Continuous Update
        b. Enable Only Recovery Disk
        c. Enable Only Master Disk

II � Intel(R) Optane(TM) Memory Technology Management
1. �Deconcatenate� Intel(R) Optane(TM) Memory Volume
   Use this option to disable Intel(R) Optane(TM) memory volume and return the system to a non-Accelerated 
   Pass-through configuration.
     a. [X] Checkbox to preserve user data upon deconcatenation; Checked is the default
     b. <No> Decision box to confirm deconcatenation action; Yes or No (No is default)
   
**************************************************************************
* 13.  OPTIONS TO RESET THE RAID VOLUME in the INTEL(R) RST Pre-OS UI's
**************************************************************************
WARNING!!!!!!!!!!!!!!WARNING!!!!!!!!!!!!WARNING!!!!!!!!!WARNING!!!!!!!!!!WARNING!!!!!!!!
Before completing any of the following steps, it is recommended you Backup any wanted 
data that is located on the RAID volumes being deleted or disks being reset to non-RAID

Intel(R) Rapid Storage Technology - pre-OS UI provides two methods for resetting the RAID 
volume:
    > Delete RAID Volume
    > Reset Disks to Non-RAID

   Differences between the options are noted below. Users are advised to select the option 
   based on the situation.

13.1 Delete RAID Volume
     When a RAID volume is deleted, RAID metadata on the participating disks is erased and 
     sector zero is cleared; as a result, the partition table and file system related data      
     are reset. Windows installer will not see any invalid data at the time of OS 
     installation. This is the recommended method for reconfiguring the RAID volume and 
     installing OS on it.

13.2 Reset Disks to Non-RAID
     This option is used to reset the metadata on the disk which participates in more than 
     one RAID volume in single operation. It should be used if 'Delete RAID Volume' option 
     fails for any reason and to reset a disk that has been marked as Spare and offline 
     member. When a disk in the RAID volume is reset to non-RAID, RAID metadata is erased. 
     However, partition table and file system related data still exists, which may be 
     invalid. This might cause Windows installer to misinterpret the information available 
     on the 'reset disk' at the time of installation. This could result in unexpected 
     behavior in OS installation.

**************************************************************************
* DISCLAIMER
**************************************************************************

INFORMATION IN THIS DOCUMENT IS PROVIDED IN CONNECTION WITH INTEL PRODUCTS. NO LICENSE, 
EXPRESS OR IMPLIED, BY ESTOPPEL OR OTHERWISE, TO ANY INTELLECTUAL PROPERTY RIGHTS IS 
GRANTED BY THIS DOCUMENT. EXCEPT AS PROVIDED IN INTEL'S TERMS AND CONDITIONS OF SALE FOR 
SUCH PRODUCTS, INTEL ASSUMES NO LIABILITY WHATSOEVER AND INTEL DISCLAIMS ANY EXPRESS
OR IMPLIED WARRANTY, RELATING TO SALE AND/OR USE OF INTEL PRODUCTS INCLUDING LIABILITY OR 
WARRANTIES RELATING TO FITNESS FOR A PARTICULAR PURPOSE, MERCHANTABILITY, OR INFRINGEMENT 
OF ANY PATENT, COPYRIGHT OR OTHER INTELLECTUAL PROPERTY RIGHT.

UNLESS OTHERWISE AGREED IN WRITING BY INTEL, THE INTEL PRODUCTS ARE NOT DESIGNED NOR 
INTENDED FOR ANY APPLICATION IN WHICH THE FAILURE OF THE INTEL PRODUCT COULD CREATE A 
SITUATION WHERE PERSONAL INJURY OR DEATH MAY OCCUR.

Intel may make changes to specifications and product descriptions at any time, without 
notice. Designers must not rely on the absence or characteristics of any features or 
instructions marked "reserved" or "undefined". Intel reserves these for future definition 
and shall have no responsibility whatsoever for conflicts or incompatibilities arising 
from future changes to them. The information here is subject to change without notice. Do 
not finalize a design with this information.

The products described in this document may contain design defects or errors known as 
errata which may cause the product to deviate from published specifications. Current 
characterized errata are available on request.

Contact your local Intel sales office or your distributor to obtain the latest 
specifications and before placing your product order.

Copies of documents which have an order number and are referenced in this document, or 
other Intel literature, may be obtained by calling 1-800-548-4725, or go to: 
http://www.intel.com/#/en_us_01

Intel(R) is a trademark of Intel Corporation or its subsidiaries in the U.S. and/or other countries.

* Other names and brands may be claimed as the property of others

Copyright (C) Intel Corporation. All rights reserved.

***************************************************************************
* INTEL SOFTWARE LICENSE AGREEMENT
***************************************************************************
