@ echo off
title Install License Certificate for Windows 10/11 - AVL
mode con: cols=63 lines=33
color 1b
fsutil dirty query %systemdrive%  >nul 2>&1 || (
echo ==== ERROR ====
echo You run this tool not as administrator role.
echo Please Run as administrator.
echo Chay ung dung bang quyen quan tri vien!
echo Press any key to exit...
pause >nul
exit
)
ECHO OFF
CLS
:MENU
ECHO.
ECHO ............................................................
ECHO                         PITVN Community
ECHO            https://www.facebook.com/groups/PITVN
ECHO         TOOL FOR INSTALL LICENSE (SKUS) WINDOWS 10-11
ECHO          (For All version, Not include version 1511) 
ECHO           Author: AnthonyVL - Update 03 October 024
ECHO ............................................................

ECHO.
ECHO  0. Exit
ECHO  1. Install License Windows 10/11 Pro.
ECHO  2. Install License Windows 10/11 Home(Core).
ECHO  3. Install License Windows 10/11 ProN.
ECHO  4. Install License Windows 10/11 HomeN(CoreN).
ECHO  5. Install License Windows 10/11 Home Single Language.
Echo  6. Install License Windows 10/11 Enterprise.
Echo  7. Install License Windows 10 Enterprise LTSB 2015.
Echo  8. Install License Windows 10 Enterprise LTSB 2016.
Echo  9. Install License Windows 10 Enterprise LTSC 2019.
Echo 10. Install License Windows 10/11 Education.
Echo 11. Install License Windows 10/11 EducationN.
Echo 12. Install License Windows 10/11 EnterpriseN.
Echo 13. Install License Windows 10/11 ProfessionalEducation.
Echo 14. Install License Windows 10/11 ProfessionalEducationN.
Echo 15. Install License Windows 10/11 ProfessionalSingleLanguage.
Echo 16. Install License Windows 10/11 ProfessionalWorkstation.
Echo 17. Install License Windows 10/11 ProfessionalWorkstationN.
Echo 18. Install License Windows 10/11 IoT Enterprise.
Echo 19. Install License Windows 10 Enterprise LTSC 2021.
Echo 20. Install License Windows 11 Enterprise LTSC 2024.

Set Pro=VK7JG-NPHTM-C97JM-9MPGT-3V66T
Set Core=YTMG3-N6DKC-DKB77-7M9GH-8HVX7
Set CoreN=4CPRK-NM3K3-X6XXQ-RXX86-WXCHW	
Set ProN=2B87N-8KFHP-DKV6R-Y2C8J-PKCKT
Set CoreSL=BT79Q-G7N6G-PGBYW-4YWX6-6F4BT
Set Enterprise=XGVPP-NMH47-7TTHJ-W3FW7-8HV2C		
Set ProWorkstations=DXG7C-N36C4-C4HTG-X4T3X-2YV77
Set EnterpriseN=WGGHN-J84D6-QYCPR-T7PJ7-X766F
Set LTSB2015=CJ4JF-8KNY7-PCH2B-Y6B49-MG9R8
Set LTSB2016=NK96Y-D9CD8-W44CQ-R8YTK-DYJWX
Set LTSC2019=93MGM-NTFKD-6BK63-R6FYR-6Q9PB
Set LTSC2021=YYN9T-4B9BJ-C7C23-7HCKQ-Y4KPP
Set LTSC2024=3B999-Y9NT7-CHDJ3-3KYPR-4YCPV
Set Education=YNMGQ-8RYV3-4PGQ3-C8XTP-7CFBY
Set EducationN=84NGF-MHBT6-FXBX8-QWJK7-DRR8H
Set EnterpriseN=3V6Q6-NQXCX-V8YXR-9QCYV-QPFCT
Set ProfessionalEducation=8PTT6-RNW4C-6V7J2-C2D3X-MHBPB
Set ProfessionalEducationN=GJTYN-HDMQY-FRR76-HVGC7-QPF8P
Set ProfessionalSingleLanguage=G3KNM-CHG6T-R36X3-9QDG6-8M8K9
Set ProfessionalWorkstation=DXG7C-N36C4-C4HTG-X4T3X-2YV77
Set ProfessionalWorkstationN=WYPNQ-8C467-V2W6J-TX4WX-WT2RQ
Set IoTEnterprise=XQQYW-NFFMW-XJPBH-K8732-CKFFD

ECHO.
SET /P M=Choose a Number (0,1,2,...,19,20) then press ENTER:
IF %M%==1 GOTO Pro
IF %M%==2 GOTO HOME
IF %M%==3 GOTO ProN
IF %M%==4 GOTO CoreN
IF %M%==5 GOTO CoreSL
IF %M%==6 GOTO Enterprise
IF %M%==7 GOTO LTSB2015
IF %M%==8 GOTO LTSB2016
IF %M%==9 GOTO LTSC2019
IF %M%==10 GOTO Education
IF %M%==11 GOTO EducationN
IF %M%==12 GOTO EnterpriseN
IF %M%==13 GOTO ProfessionalEducation
IF %M%==14 GOTO ProfessionalEducationN
IF %M%==15 GOTO ProfessionalSingleLanguage
IF %M%==16 GOTO ProfessionalWorkstation
IF %M%==17 GOTO EnterpriseN
IF %M%==18 GOTO IoTEnterprise
IF %M%==19 GOTO LTSC2021
IF %M%==20 GOTO LTSC2024
IF %M%==0 GOTO TheEnd

:LTSC2024
cd /d "%~dp0"
xcopy sku\EnterpriseS %windir%\System32\spp\tokens\skus\EnterpriseS /i
cscript.exe %windir%\system32\slmgr.vbs /rilc
cscript.exe %windir%\system32\slmgr.vbs /upk >nul 2>&1
cscript.exe %windir%\system32\slmgr.vbs /ckms >nul 2>&1
cscript.exe %windir%\system32\slmgr.vbs /cpky >nul 2>&1
cscript.exe %windir%\system32\slmgr.vbs /ipk %LTSC2024%
sc config LicenseManager start= auto & net start LicenseManager
sc config wuauserv start= auto & net start wuauserv
clipup -v -o -altto c:\
echo
echo Finish.
pause
GOTO MENU

:LTSC2021
cd /d "%~dp0"
xcopy sku\EnterpriseS %windir%\System32\spp\tokens\skus\EnterpriseS /i
cscript.exe %windir%\system32\slmgr.vbs /rilc
cscript.exe %windir%\system32\slmgr.vbs /upk >nul 2>&1
cscript.exe %windir%\system32\slmgr.vbs /ckms >nul 2>&1
cscript.exe %windir%\system32\slmgr.vbs /cpky >nul 2>&1
cscript.exe %windir%\system32\slmgr.vbs /ipk %LTSC2021%
sc config LicenseManager start= auto & net start LicenseManager
sc config wuauserv start= auto & net start wuauserv
clipup -v -o -altto c:\
echo
echo Finish.
pause
GOTO MENU

:IoTEnterprise
cd /d "%~dp0"
xcopy sku\IoTEnterprise %windir%\System32\spp\tokens\skus\IoTEnterprise /i
cscript.exe %windir%\system32\slmgr.vbs /rilc
cscript.exe %windir%\system32\slmgr.vbs /upk >nul 2>&1
cscript.exe %windir%\system32\slmgr.vbs /ckms >nul 2>&1
cscript.exe %windir%\system32\slmgr.vbs /cpky >nul 2>&1
cscript.exe %windir%\system32\slmgr.vbs /ipk %IoTEnterprise%
sc config LicenseManager start= auto & net start LicenseManager
sc config wuauserv start= auto & net start wuauserv
clipup -v -o -altto c:\
echo
echo Finish.
pause
GOTO MENU

:PRO
cd /d "%~dp0"
xcopy sku\Professional %windir%\System32\spp\tokens\skus\Professional /i
cscript.exe %windir%\system32\slmgr.vbs /rilc
cscript.exe %windir%\system32\slmgr.vbs /upk >nul 2>&1
cscript.exe %windir%\system32\slmgr.vbs /ckms >nul 2>&1
cscript.exe %windir%\system32\slmgr.vbs /cpky >nul 2>&1
cscript.exe %windir%\system32\slmgr.vbs /ipk %Pro%
sc config LicenseManager start= auto & net start LicenseManager
sc config wuauserv start= auto & net start wuauserv
clipup -v -o -altto c:\
echo
echo Finish.
pause
GOTO MENU

:HOME
cd /d "%~dp0"
xcopy sku\Core %windir%\System32\spp\tokens\skus\Core /i /y
cscript.exe %windir%\system32\slmgr.vbs /rilc
cscript.exe %windir%\system32\slmgr.vbs /upk >nul 2>&1
cscript.exe %windir%\system32\slmgr.vbs /ckms >nul 2>&1
cscript.exe %windir%\system32\slmgr.vbs /cpky >nul 2>&1
cscript.exe %windir%\system32\slmgr.vbs /ipk %Core%
sc config LicenseManager start= auto & net start LicenseManager
sc config wuauserv start= auto & net start wuauserv
clipup -v -o -altto c:\
echo
echo Finish.
pause
GOTO MENU

:ProN
cd /d "%~dp0"
xcopy sku\ProfessionalN %windir%\System32\spp\tokens\skus\ProfessionalN /i /y
cscript.exe %windir%\system32\slmgr.vbs /rilc
cscript.exe %windir%\system32\slmgr.vbs /upk >nul 2>&1
cscript.exe %windir%\system32\slmgr.vbs /ckms >nul 2>&1
cscript.exe %windir%\system32\slmgr.vbs /cpky >nul 2>&1
cscript.exe %windir%\system32\slmgr.vbs /ipk %ProN%
sc config LicenseManager start= auto & net start LicenseManager
sc config wuauserv start= auto & net start wuauserv
clipup -v -o -altto c:\
echo
echo Finish.
pause
GOTO MENU

:CoreN
cd /d "%~dp0"
xcopy sku\CoreN %windir%\System32\spp\tokens\skus\CoreN /i /y
cscript.exe %windir%\system32\slmgr.vbs /rilc
cscript.exe %windir%\system32\slmgr.vbs /upk >nul 2>&1
cscript.exe %windir%\system32\slmgr.vbs /ckms >nul 2>&1
cscript.exe %windir%\system32\slmgr.vbs /cpky >nul 2>&1
cscript.exe %windir%\system32\slmgr.vbs /ipk %CoreN%
sc config LicenseManager start= auto & net start LicenseManager
sc config wuauserv start= auto & net start wuauserv
clipup -v -o -altto c:\
echo
echo Finish.
pause
GOTO MENU

:CoreSL
cd /d "%~dp0"
xcopy sku\CoreSingleLanguage %windir%\System32\spp\tokens\skus\CoreSingleLanguage /i /y
cscript.exe %windir%\system32\slmgr.vbs /rilc
cscript.exe %windir%\system32\slmgr.vbs /upk >nul 2>&1
cscript.exe %windir%\system32\slmgr.vbs /ckms >nul 2>&1
cscript.exe %windir%\system32\slmgr.vbs /cpky >nul 2>&1
cscript.exe %windir%\system32\slmgr.vbs /ipk %CoreSL%
sc config LicenseManager start= auto & net start LicenseManager
sc config wuauserv start= auto & net start wuauserv
clipup -v -o -altto c:\
echo
echo Finish.
pause
GOTO MENU

:Enterprise
cd /d "%~dp0"
xcopy sku\Enterprise %windir%\System32\spp\tokens\skus\Enterprise /i /y
cscript.exe %windir%\system32\slmgr.vbs /rilc
cscript.exe %windir%\system32\slmgr.vbs /upk >nul 2>&1
cscript.exe %windir%\system32\slmgr.vbs /ckms >nul 2>&1
cscript.exe %windir%\system32\slmgr.vbs /cpky >nul 2>&1
cscript.exe %windir%\system32\slmgr.vbs /ipk %Enterprise%
sc config LicenseManager start= auto & net start LicenseManager
sc config wuauserv start= auto & net start wuauserv
clipup -v -o -altto c:\
echo
echo Finish.
pause
GOTO MENU

:LTSB2015
cd /d "%~dp0"
xcopy sku\wdLTSB2015\EnterpriseS %windir%\System32\spp\tokens\skus\EnterpriseS /i /y
xcopy sku\wdLTSB2015\csvlk-pack %windir%\System32\spp\tokens\skus\csvlk-pack /i /y
cscript.exe %windir%\system32\slmgr.vbs /rilc
cscript.exe %windir%\system32\slmgr.vbs /upk >nul 2>&1
cscript.exe %windir%\system32\slmgr.vbs /ckms >nul 2>&1
cscript.exe %windir%\system32\slmgr.vbs /cpky >nul 2>&1
cscript.exe %windir%\system32\slmgr.vbs /ipk %LTSB2015%
sc config LicenseManager start= auto & net start LicenseManager
sc config wuauserv start= auto & net start wuauserv
clipup -v -o -altto c:\
echo
echo Finish.
pause
GOTO MENU

:LTSB2016
cd /d "%~dp0"
xcopy sku\wdLTSB2016\EnterpriseS %windir%\System32\spp\tokens\skus\EnterpriseS /i /y
cscript.exe %windir%\system32\slmgr.vbs /rilc
cscript.exe %windir%\system32\slmgr.vbs /upk >nul 2>&1
cscript.exe %windir%\system32\slmgr.vbs /ckms >nul 2>&1
cscript.exe %windir%\system32\slmgr.vbs /cpky >nul 2>&1
cscript.exe %windir%\system32\slmgr.vbs /ipk %LTSB2016%
sc config LicenseManager start= auto & net start LicenseManager
sc config wuauserv start= auto & net start wuauserv
clipup -v -o -altto c:\
echo
echo Finish.
pause
GOTO MENU

:LTSC2019
cd /d "%~dp0"
xcopy sku\wdLTSC2019\EnterpriseS %windir%\System32\spp\tokens\skus\EnterpriseS /i /y
cscript.exe %windir%\system32\slmgr.vbs /rilc
cscript.exe %windir%\system32\slmgr.vbs /upk >nul 2>&1
cscript.exe %windir%\system32\slmgr.vbs /ckms >nul 2>&1
cscript.exe %windir%\system32\slmgr.vbs /cpky >nul 2>&1
cscript.exe %windir%\system32\slmgr.vbs /ipk %LTSC2019%
sc config LicenseManager start= auto & net start LicenseManager
sc config wuauserv start= auto & net start wuauserv
clipup -v -o -altto c:\
echo
echo Finish.
pause
GOTO MENU

:Education
cd /d "%~dp0"
xcopy sku\Education %windir%\System32\spp\tokens\skus\Education /i /y
cscript.exe %windir%\system32\slmgr.vbs /rilc
cscript.exe %windir%\system32\slmgr.vbs /upk >nul 2>&1
cscript.exe %windir%\system32\slmgr.vbs /ckms >nul 2>&1
cscript.exe %windir%\system32\slmgr.vbs /cpky >nul 2>&1
cscript.exe %windir%\system32\slmgr.vbs /ipk %Education%
sc config LicenseManager start= auto & net start LicenseManager
sc config wuauserv start= auto & net start wuauserv
clipup -v -o -altto c:\
echo
echo Finish.
pause
GOTO MENU

:EducationN
cd /d "%~dp0"
xcopy sku\EducationN %windir%\System32\spp\tokens\skus\EducationN /i /y
cscript.exe %windir%\system32\slmgr.vbs /rilc
cscript.exe %windir%\system32\slmgr.vbs /upk >nul 2>&1
cscript.exe %windir%\system32\slmgr.vbs /ckms >nul 2>&1
cscript.exe %windir%\system32\slmgr.vbs /cpky >nul 2>&1
cscript.exe %windir%\system32\slmgr.vbs /ipk %EducationN%
sc config LicenseManager start= auto & net start LicenseManager
sc config wuauserv start= auto & net start wuauserv
clipup -v -o -altto c:\
echo
echo Finish.
pause
GOTO MENU

:EnterpriseN
cd /d "%~dp0"
xcopy sku\EnterpriseN %windir%\System32\spp\tokens\skus\EnterpriseN /i /y
cscript.exe %windir%\system32\slmgr.vbs /rilc
cscript.exe %windir%\system32\slmgr.vbs /upk >nul 2>&1
cscript.exe %windir%\system32\slmgr.vbs /ckms >nul 2>&1
cscript.exe %windir%\system32\slmgr.vbs /cpky >nul 2>&1
cscript.exe %windir%\system32\slmgr.vbs /ipk %EnterpriseN%
sc config LicenseManager start= auto & net start LicenseManager
sc config wuauserv start= auto & net start wuauserv
clipup -v -o -altto c:\
echo
echo Finish.
pause
GOTO MENU

:ProfessionalEducation
cd /d "%~dp0"
xcopy sku\ProfessionalEducation %windir%\System32\spp\tokens\skus\ProfessionalEducation /i /y
cscript.exe %windir%\system32\slmgr.vbs /rilc
cscript.exe %windir%\system32\slmgr.vbs /upk >nul 2>&1
cscript.exe %windir%\system32\slmgr.vbs /ckms >nul 2>&1
cscript.exe %windir%\system32\slmgr.vbs /cpky >nul 2>&1
cscript.exe %windir%\system32\slmgr.vbs /ipk %ProfessionalEducation%
sc config LicenseManager start= auto & net start LicenseManager
sc config wuauserv start= auto & net start wuauserv
clipup -v -o -altto c:\
echo
echo Finish.
pause
GOTO MENU

:ProfessionalEducationN
cd /d "%~dp0"
xcopy sku\ProfessionalEducationN %windir%\System32\spp\tokens\skus\ProfessionalEducationN /i /y
cscript.exe %windir%\system32\slmgr.vbs /rilc
cscript.exe %windir%\system32\slmgr.vbs /upk >nul 2>&1
cscript.exe %windir%\system32\slmgr.vbs /ckms >nul 2>&1
cscript.exe %windir%\system32\slmgr.vbs /cpky >nul 2>&1
cscript.exe %windir%\system32\slmgr.vbs /ipk %ProfessionalEducationN%
sc config LicenseManager start= auto & net start LicenseManager
sc config wuauserv start= auto & net start wuauserv
clipup -v -o -altto c:\
echo
echo Finish.
pause
GOTO MENU

:ProfessionalSingleLanguage
cd /d "%~dp0"
xcopy sku\ProfessionalSingleLanguage %windir%\System32\spp\tokens\skus\ProfessionalSingleLanguage /i /y
cscript.exe %windir%\system32\slmgr.vbs /rilc
cscript.exe %windir%\system32\slmgr.vbs /upk >nul 2>&1
cscript.exe %windir%\system32\slmgr.vbs /ckms >nul 2>&1
cscript.exe %windir%\system32\slmgr.vbs /cpky >nul 2>&1
cscript.exe %windir%\system32\slmgr.vbs /ipk %ProfessionalSingleLanguage%
sc config LicenseManager start= auto & net start LicenseManager
sc config wuauserv start= auto & net start wuauserv
clipup -v -o -altto c:\
echo
echo Finish.
pause
GOTO MENU

:ProfessionalWorkstation
cd /d "%~dp0"
xcopy sku\ProfessionalWorkstation %windir%\System32\spp\tokens\skus\ProfessionalWorkstation /i /y
cscript.exe %windir%\system32\slmgr.vbs /rilc
cscript.exe %windir%\system32\slmgr.vbs /upk >nul 2>&1
cscript.exe %windir%\system32\slmgr.vbs /ckms >nul 2>&1
cscript.exe %windir%\system32\slmgr.vbs /cpky >nul 2>&1
cscript.exe %windir%\system32\slmgr.vbs /ipk %ProfessionalWorkstation%
sc config LicenseManager start= auto & net start LicenseManager
sc config wuauserv start= auto & net start wuauserv
clipup -v -o -altto c:\
echo
echo Finish.
pause
GOTO MENU

:TheEnd
Start https://www.facebook.com/groups/PITVN
Exit

:ProfessionalWorkstationN
cd /d "%~dp0"
xcopy sku\ProfessionalWorkstationN %windir%\System32\spp\tokens\skus\ProfessionalWorkstationN /i /y
cscript.exe %windir%\system32\slmgr.vbs /rilc
cscript.exe %windir%\system32\slmgr.vbs /upk >nul 2>&1
cscript.exe %windir%\system32\slmgr.vbs /ckms >nul 2>&1
cscript.exe %windir%\system32\slmgr.vbs /cpky >nul 2>&1
cscript.exe %windir%\system32\slmgr.vbs /ipk %ProfessionalWorkstationN%
sc config LicenseManager start= auto & net start LicenseManager
sc config wuauserv start= auto & net start wuauserv
clipup -v -o -altto c:\
echo
echo Finish.
pause
GOTO MENU